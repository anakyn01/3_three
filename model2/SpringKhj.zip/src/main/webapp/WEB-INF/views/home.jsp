<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<jsp:include page="include/header.jsp" flush="false"/> <!-- flush true를 하면 버퍼로 보관하다 전달 -->

<div class="container">
<div class="row">
<div class="col-md-12">

</div>
</div>
</div>

<jsp:include page="include/footer.jsp" flush="false"/>