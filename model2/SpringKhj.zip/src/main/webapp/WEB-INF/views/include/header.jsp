<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%><!-- jstl로 절대경로 이건 외울것-->
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<title>Insert title here</title>
</head>
<body>
<p class="p-3">
<a href="${contextPath}/" class="a-link">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M21 13v10h-6v-6h-6v6h-6v-10h-3l12-12 12 12h-3zm-1-5.907v-5.093h-3v2.093l3 3z"/></svg>
</a>
<button class="btn btn-warning" data-bs-toggle="offcanvas" data-bs-target="#demo">
메뉴
</button>
</p>

<div id="demo" class="offcanvas offcanvas-start text-bg-dark">
	<div class="offcanvas-header">
		<h1 class="offcanvas-title">CRUD</h1>
		<button class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
	</div>
	<div class="offcanvas-body">
		<a href="${contextPath}/create" class="a-link">쓰기</a><br>
		<a href="${contextPath}/list" class="a-link">리스트</a><br>
	</div>
</div>