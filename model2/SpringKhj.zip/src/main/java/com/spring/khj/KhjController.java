package com.spring.khj;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.khj.service.BookService;


@Controller // 어노테이션[다른 프로그램에게 유용한 정보를 제공하기 위해 사용하는] 주석
// 프로젝트를 관리하는 콘트롤러로 임명시킴 / 기능을 수행하도록 하는 기술
public class KhjController {
	// 입력기능 서비스를 호출하기 위해서 서비스 빈(컴포넌트->언제든 재사용 가능)을 추가한다 -> bookservice
	@Autowired
	BookService bookservice;

	@GetMapping(value="/") // 웹에서 라우팅 할 때 사용
	public String home() {
		return "home";
	}
	
//	@GetMapping(value="/create") // 웹에서 라우팅 할 때 사용
//	public String create() {
//		return "/sub/create";
//	}
	
	// create 주소가 GET방식으로 입력되었을 때 sub/create에 대한 경로의 뷰를 보여준다
	// ModelAndView 객체를 생성해서 객체 형식으로 리턴
	// @GetMapping과 @PostMapping을 같이 사용(Model의 경우 PostMapping만 사용)
	@GetMapping(value="/create")
	public ModelAndView create() {
		return new ModelAndView("/sub/create");	
	}
	
	// 쓰기 모델 -> 객체로 url과 모델을 리턴시키는 메소드(ModelAndView)
	// @RequestMapping(value="/create",method = RequestMethod.POST)
	// @RequestParam => HTTP의 쿼리스트링이나 폼데이터를 메소드의 파라미터로 바인딩할때 사용
	// 바인딩 => 프로그램의 어떤 기본 단위가 가질 수 있는 구성요소의 구체적인 값 성격을 확정하는 것을 말함
	@PostMapping(value="/create") // 스프링 버전이 3.대이면 사용 불가능 -> 스프링 버전 업 해줘야 함
	public ModelAndView createPost(@RequestParam Map<String, Object> map) {
	// 1) 객체 정의
	ModelAndView mav = new ModelAndView();
	// 2) 변수에 서비스를 대입
	String bookId = this.bookservice.create(map);
	// 3) 정상적이라면 실행시키고 뷰페이지를 리턴시키고, 그렇지 않으면 글을 쓰는 상태로 돌림
	if(bookId == null) { // 정상적인게 아니라면 원래 글을 쓰는 화면으로 돌리고
		mav.setViewName("redirect:/create");
	} else {
		mav.setViewName("redirect:/detail?bookId="+bookId);
	}
	return mav;
	}

/* 쓰기 프로세스
1) 마이바티스 태그 생성
2) 콘트롤러 @GetMapping url생성
3) DAO생성 autowired로 sql세션 템플릿 가져옴
4) 실제 비즈니스로직이 흐르는 서비스를 생성
5) 콘트롤러에서 서비스 오토와이어드
6) 오토와이어드한 서비스를 콘트롤러에서 실행
*/
	
	
	
}
