package com.spring.khj.service;

import java.util.Map;

public interface BookService {

	String create(Map<String, Object> map); // create 메소드 시그니처

}
