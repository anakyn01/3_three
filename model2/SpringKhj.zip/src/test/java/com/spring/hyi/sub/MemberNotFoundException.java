package com.spring.hyi.sub;

public class MemberNotFoundException extends RuntimeException{

}
