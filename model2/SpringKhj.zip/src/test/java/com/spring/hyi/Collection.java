package com.spring.hyi;

import java.util.ArrayList;
import java.util.List;

import com.spring.hyi.sub.Board;

public class Collection {

	public static void main(String[] args) {
		
		// ArrayList 컬렉션 생성
		List<Board> list = new ArrayList<>();
		
		// 객체에 내용을 추가
		list.add(new Board("제목1","내용1","글쓴이1"));
		list.add(new Board("제목2","내용2","글쓴이2"));
		list.add(new Board("제목3","내용3","글쓴이3"));
		list.add(new Board("제목4","내용4","글쓴이4"));
		list.add(new Board("제목5","내용5","글쓴이5"));
		list.add(new Board("제목5","내용5","글쓴이5"));
		
		// 질문 : 동일한 객체라는 말이 내용을 동일한 것으로 하나 더 만들면 어떻게 되는가? 같은 주소에 저장되나
		
		// 저장된 총 객체의 수를 얻는다
		int size = list.size();
		System.out.println("총 객체 수: " + size);
		System.out.println(); // 여백 출력
		
		// 특정 인덱스의 객체 가져오기
		Board board = list.get(2);
		System.out.println(board.getSubject() + "\t" + board.getContent() + "\t" + board.getWriter());
		System.out.println();
//		Board board5 = list.get(5);
//		System.out.println(board5.getSubject() + "\t" + board5.getContent() + "\t" + board5.getWriter());
//		System.out.println();
		
		// 모든 객체를 하나씩 가져오기
		for(int i=0; i < list.size(); i++) {
			Board b = list.get(i);
			System.out.println(b.getSubject() + "\t" + b.getContent() + "\t" + b.getWriter());
			
		}
		System.out.println();
		
		// 객체 삭제 2번 인덱스를 삭제하면 3번 인덱스가 2번 인덱스로 변경되므로 다시 2번 인덱스를 제거할 수 있음
		list.remove(4);
		list.remove(2);
		list.remove(2);
		
		
		// 삭제한 리스트 다시 출력해보기
		for(Board b : list) {
			System.out.println(b.getSubject() + "\t" + b.getContent() + "\t" + b.getWriter());
		}
		
		
		
/*
ArrayList
- 컬렉션에서 가장 많이 사용하는 컬렉션
객체를 추가하면 내부 배열에 객체가 저장된다
일반 내장 배열(내장 Array)과의 차이점은 ArrayList는 제한 없이 객체를 추가할 수 있다
list컬렉션은 객체 자체를 저장하는 것이 아니라 객체의 번지를 저장한다
동일한 객체를 중복 저장할 수 있는데 이 경우에는 동일한 번지가 저장된다 -> 하나만 저장됨
null 또한 저장이 가능하다

ArrayList컬렉션은 아래와 같이 생성할 수 있다
List<E> list = new ArrayList<E>(); => E에는 지정된 타입의 객체만 저장
List<E> list = new ArrayList<>(); => E에는 지정된 타입의 객체만 저장 -> 앞에서 E를 지정해줬기 때문에 뒤에서 생략가능

List list = new ArrayList(); => 모든 타입의 객체를 저장

ArrayList 컬렉션에 객체를 추가하면 인덱스 0번부터 차례대로 저장된다
특정 인덱스의 객체를 제거하면 바로 뒤 인덱스부터 마지막까지 전부 앞으로 당겨지고, 특정 인덱스에 객체를 삽입하면 1씩 밀려난다

따라서 빈번한 객체 삭제와 삽입이 일어나는 곳에서는 ArrayList를 사용하는 것은 바람직하지 않다
그래서 나온 것이 롬복에 빌더패턴 대신에 이런 경우라면 LinkedList를 사용하는 것이 좋다


List 컬렉션
- 객체를 인덱스로 관리하기 때문에 객체를 저장하면 인덱스가 부여되고 인덱스로 객체를 검색, 삭제 할 수 있는 기능을 제공

객체 추가 : 
boolean add[주어진 객체를 맨 끝에 추가], 
void add[주어진 인덱스에 객체를 추가], 
set[주어진 인덱스의 객체를 새로운 객체로 바꿔줌]

객체 검색 : 
boolean contains[주어진 객체가 저장되어 있는지 여부를 확인], 
get[주어진 인덱스에 저장된 객체를 return], 
isEmpty[컬렉션이 비어 있는지 조사], 
int size[저장되어 있는 전체 객체수를 리턴]

객체 삭제 : 
void clear[저장된 모든 객체를 삭제], 
remove[주어진 인덱스에 저장된 객체를 삭제], 
boolean remove[주어진 객체를 삭제]

 */
		
String collection = "자바는 널리 알려져 있는 자료구조 객체들을 효율적으로 추가, 삭제, 검색\n"+
"할 수 있도록 관련된 인터페이스와 클래스들을 java.util 패키지에 포함시켜 놓았다\\n"+
"이를 통틀어 컬렉션 프레임워크라 한다\\n"+
"컬렉션 프레임워크는 몇 가지 인터페이스를 통해서 다양한 클래스를 이용할 수 있다\\n"+
"주요 인터페이스로는 List, Set, Map이 있다\\n"+
"1) List = ArrayList, Vector, LinkedList [순서를 유지하고 저장, 중복 저장 가능]\\n"+
"2) Set = HashSet, TreeSet [순서를 유지하지 않음, 중복 저장 안됨(unique개념이라 추정됨 - 내 개인 생각)]\\n"+
"3) Map = HashMap, Hashtable, TreeMap, Properties[키와 값으로(key&value) 구성된 엔트리, 키는 중복 저장 안됨]\\n";
	}

}
