package com.spring.hyi.sub;

public class WrongIdPasswordException extends RuntimeException{

}
