package com.spring.hyi;

import java.util.*;

public class TestThread {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<Integer>();
        Vector<Integer> vec = new Vector<>();

        new Thread(() -> {
            long startTime = System.currentTimeMillis(); // 코드 시작 시간
			
            // 천만번 add 하기
            for(int i = 0; i < 10000000; i++) {
                list.add(1);
            }

            long endTime = System.currentTimeMillis(); // 코드 끝난 시간

            long durationTimeSec = endTime - startTime;
            System.out.println("ArrayList 속도 : " + durationTimeSec + "m/s"); // 밀리세컨드 출력
        }).start();

        new Thread(() -> {
            long startTime = System.currentTimeMillis(); // 코드 시작 시간
			
            // 천만번 add 하기
            for(int i = 0; i < 10000000; i++) {
                vec.add(1);
            }

            long endTime = System.currentTimeMillis(); // 코드 끝난 시간

            long durationTimeSec = endTime - startTime;
            System.out.println("Vector 속도 : " + durationTimeSec + "m/s"); // 밀리세컨드 출력
        }).start();
    }
}
