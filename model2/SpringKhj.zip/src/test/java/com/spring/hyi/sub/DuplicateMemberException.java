package com.spring.hyi.sub;

public class DuplicateMemberException extends RuntimeException{

	public DuplicateMemberException(String message) {
		super(message);
	}
}
