package com.my.homework.servcie;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.my.homework.dao.HomeDAO;
import com.my.homework.mapper.BlogMapper;

@Service
public class HomeImpl implements HomeService{

	private HomeDAO homeDAO;
	private BlogMapper blogMapper;
	
	@Autowired
	public HomeImpl(HomeDAO homeDAO, BlogMapper blogMapper) {
		this.homeDAO = homeDAO;
		this.blogMapper = blogMapper;
	}

	@Override
	public int create(Map<String, Object> map) {
		int seq = this.homeDAO.insert(map);
		return seq;
	}
	
	@Override
	public boolean delete(int blogContSeq) {
		return this.blogMapper.delete(blogContSeq) > 0;
	}

	@Override //read
	public Map<String, Object> read(int blogContSeq) {
		Map<String, Object> blogCont = this.homeDAO.selectOne(blogContSeq);
		return blogCont;
	}
	
	
	
	
	
	
	

}