package com.my.homework.mapper;

public interface BlogMapper {
int delete(int blogContSeq);
}
