package com.my.homework.servcie;

import java.util.*;

public interface HomeService {

	int create(Map<String, Object> map);
	
	//read 메소드 시그니처
	Map<String, Object> read (int blogContSeq);

	//delete 메소드 시그니처
	boolean delete(int blogContSeq);

	
}
